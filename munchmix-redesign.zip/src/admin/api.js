import { supabase } from '../supabaseClient';

const must = (res) => {
  if (res.error) throw new Error(res.error.message || 'Server error');
  return res.data;
};

// the server gives 1000 rows at a time, so read every page
async function allPages(build) {
  let out = [];
  for (let from = 0; from < 20000; from += 1000) {
    const d = must(await build().range(from, from + 999));
    out = out.concat(d || []);
    if (!d || d.length < 1000) break;
  }
  return out;
}

export async function getStats() {
  return must(await supabase.rpc('admin_stats'));
}

export async function getPrizes() {
  const d = must(await supabase.from('prizes').select('id,name,description,image_url,active').order('created_at', { ascending: true }));
  return d.map((x) => ({ id: x.id, name: x.name, description: x.description || '', image: x.image_url || '', active: Boolean(x.active) }));
}

export async function getWinners() {
  const rows = await allPages(() => supabase
    .from('codes')
    .select('token,prize_id,redeemed_at,claim_name,claim_phone,claimed_at,delivered,delivered_at,prizes(name)')
    .not('prize_id', 'is', null)
    .not('redeemed_at', 'is', null)
    .order('redeemed_at', { ascending: false }));
  return rows.map((x) => ({
    token: x.token,
    prize_id: x.prize_id,
    prize_name: (x.prizes && x.prizes.name) || 'Prize',
    redeemed_at: x.redeemed_at || '',
    name: x.claim_name || '',
    phone: x.claim_phone || '',
    claimed_at: x.claimed_at || '',
    delivered: Boolean(x.delivered),
    delivered_at: x.delivered_at || '',
  }));
}

export async function savePrize(p) {
  const row = { name: p.name, description: p.description, image_url: p.image, active: p.active };
  if (p.id) must(await supabase.from('prizes').update(row).eq('id', p.id));
  else must(await supabase.from('prizes').insert(row));
}

export async function uploadPrizeImage(blob) {
  const id = window.crypto && window.crypto.randomUUID ? window.crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2);
  const name = id + '.jpg';
  const { error } = await supabase.storage.from('prizes').upload(name, blob, { contentType: 'image/jpeg', upsert: false });
  if (error) throw new Error(error.message || 'Picture upload failed');
  return supabase.storage.from('prizes').getPublicUrl(name).data.publicUrl;
}

export async function deletePrize(id) {
  return must(await supabase.rpc('admin_delete_prize', { p_id: id }));
}

export async function addCodes(batch, items) {
  return must(await supabase.rpc('admin_add_codes', { p_batch: batch, p_items: items }));
}

export async function getBatchTokens(batch) {
  const rows = await allPages(() => supabase.from('codes').select('token,serial,prize_id').eq('batch', batch).order('serial', { ascending: true }));
  return rows.map((x) => ({ t: x.token, s: x.serial, p: x.prize_id || '' }));
}

export async function setDelivered(token, value) {
  must(await supabase.from('codes').update({ delivered: value, delivered_at: value ? new Date().toISOString() : null }).eq('token', token));
}

export async function deleteTest() {
  return must(await supabase.rpc('admin_delete_test'));
}

/* ---------- customers and the club ---------- */
export async function getCustomers() {
  return must(await supabase.rpc('admin_customers'));
}

export async function markReward(id, delta) {
  return must(await supabase.rpc('admin_mark_reward', { p_id: id, p_delta: delta }));
}

export async function deleteCustomer(id) {
  return must(await supabase.rpc('admin_delete_customer', { p_id: id }));
}

export async function resetPin(id, pin) {
  return must(await supabase.rpc('admin_reset_pin', { p_id: id, p_pin: pin }));
}

export async function getLoyalty() {
  const d = must(await supabase.from('loyalty').select('enabled,target,prize_name,prize_description,prize_image_url').eq('id', 1).single());
  return { enabled: Boolean(d.enabled), target: d.target, name: d.prize_name, description: d.prize_description || '', image: d.prize_image_url || '' };
}

export async function saveLoyalty(l) {
  must(await supabase.from('loyalty').update({
    enabled: l.enabled, target: l.target, prize_name: l.name, prize_description: l.description, prize_image_url: l.image,
  }).eq('id', 1));
}
