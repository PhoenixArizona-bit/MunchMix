import React from 'react';
import { deleteTest } from './api';

export default function OverviewTab({ stats, onRefresh, onReprint, setMsg }) {
  if (!stats) return <p className="muted">Loading…</p>;
  const t = stats.totals;
  const pct = t.codes ? Math.round((t.redeemed / t.codes) * 1000) / 10 : 0;
  const boxes = [['Codes made', t.codes], ['Scanned', t.redeemed + ' (' + pct + '%)'], ['Winners', t.winners], ['Details sent', t.claimed], ['Delivered', t.delivered], ['Customers', t.customers || 0], ['Club rewards to deliver', t.rewards_due || 0]];
  const hasTest = stats.batches.some((b) => b.batch === 'TEST');

  async function removeTest() {
    if (!window.confirm('Delete the TEST codes and the test prize?')) return;
    try { await deleteTest(); await onRefresh(); } catch (e) { setMsg({ kind: 'bad', text: 'Could not delete: ' + e.message }); }
  }

  return (
    <section>
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
        <h2 style={{ margin: 0 }}>Overview</h2>
        <button className="btn small alt" type="button" onClick={onRefresh}>Refresh</button>
      </div>
      <div className="grid">
        {boxes.map(([label, value]) => (
          <div className="stat" key={label}><b>{String(value)}</b><span>{label}</span></div>
        ))}
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h2>Prize stock</h2>
        <div className="scroll">
          {stats.prizes.length ? (
            <table>
              <thead><tr>{['Prize', 'In packs', 'Won', 'Still hidden', 'Details', 'Delivered'].map((x) => <th key={x}>{x}</th>)}</tr></thead>
              <tbody>
                {stats.prizes.map((p) => (
                  <tr key={p.id}>
                    <td>{p.name}</td><td>{p.assigned}</td><td>{p.won}</td><td>{p.assigned - p.won}</td><td>{p.claimed}</td><td>{p.delivered}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : <p className="muted">No prizes yet. Add one in the Prizes tab.</p>}
        </div>
      </div>

      <div className="card">
        <h2>Print batches</h2>
        {stats.batches.length ? stats.batches.map((b) => (
          <div className="item" key={b.batch}>
            <div className="grow">
              <b>{b.batch}</b>
              <div className="muted">{b.count} codes · {b.prizes} winning · {b.redeemed} scanned</div>
            </div>
            {b.batch === 'TEST'
              ? <span className="tag">test</span>
              : <button className="btn small alt" type="button" onClick={() => onReprint(b.batch)}>Print files</button>}
          </div>
        )) : <p className="muted">No batches yet. Make your first one in Print sheets.</p>}
      </div>

      {hasTest ? (
        <div className="card">
          <h2>Test codes</h2>
          <p className="muted">The 3 TEST codes made during setup are still in your database. Remove them before launch.</p>
          <button className="btn red small" type="button" onClick={removeTest}>Delete TEST codes</button>
        </div>
      ) : null}
    </section>
  );
}
