import React, { useCallback, useEffect, useState } from 'react';
import { getCustomers, markReward, deleteCustomer, resetPin, getLoyalty, saveLoyalty, uploadPrizeImage } from './api';
import { shrinkImage } from './PrizesTab';
import { csvCell, downloadFile, fmtDate } from './qrpdf';
import Msg from './Msg';

function ClubSettings({ setMsg }) {
  const [f, setF] = useState(null);
  const [local, setLocal] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getLoyalty().then((l) => setF({ ...l, blob: null, target: String(l.target) }))
      .catch((e) => setMsg({ kind: 'bad', text: 'Could not load club settings: ' + e.message + '. Run the newest setup SQL in Supabase.' }));
  }, [setMsg]);

  if (!f) return null;
  const set = (patch) => setF((x) => ({ ...x, ...patch }));

  async function pick(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    try { const blob = await shrinkImage(file); set({ blob, image: URL.createObjectURL(blob) }); setLocal(null); }
    catch (err) { setLocal({ kind: 'bad', text: 'That picture could not be used. Try another one.' }); }
  }

  async function save() {
    const target = parseInt(f.target, 10);
    if (!(target >= 2 && target <= 10000)) { setLocal({ kind: 'bad', text: 'Packs needed must be a number from 2 to 10000.' }); return; }
    if (!f.name.trim()) { setLocal({ kind: 'bad', text: 'Give the big prize a name.' }); return; }
    setBusy(true);
    setLocal({ kind: 'info', text: 'Saving…' });
    try {
      let image = /^https:\/\//i.test(f.image) ? f.image : '';
      if (f.blob) image = await uploadPrizeImage(f.blob);
      await saveLoyalty({ enabled: f.enabled, target, name: f.name.trim(), description: f.description.trim(), image });
      set({ image, blob: null });
      setLocal({ kind: 'ok', text: 'Saved. The website shows this now.' });
    } catch (e) { setLocal({ kind: 'bad', text: 'Could not save: ' + e.message }); }
    setBusy(false);
  }

  return (
    <div className="card">
      <h2>Guaranteed prize (club)</h2>
      <p className="muted">Customers who scan this many different packs get this prize. It counts on top of the instant prizes.</p>
      <label><input type="checkbox" checked={f.enabled} onChange={(e) => set({ enabled: e.target.checked })} /> Club is ON</label>
      <label htmlFor="lgTarget">Packs needed</label>
      <input id="lgTarget" type="number" inputMode="numeric" min="2" max="10000" value={f.target} onChange={(e) => set({ target: e.target.value })} />
      <label htmlFor="lgName">Prize name</label>
      <input id="lgName" type="text" maxLength={60} value={f.name} onChange={(e) => set({ name: e.target.value })} />
      <label htmlFor="lgDesc">Short text (optional)</label>
      <textarea id="lgDesc" maxLength={200} value={f.description} onChange={(e) => set({ description: e.target.value })} />
      <label htmlFor="lgImg">Picture (optional)</label>
      <input id="lgImg" type="file" accept="image/*" onChange={pick} />
      {f.image ? (
        <div className="row" style={{ marginTop: 10 }}>
          <img className="thumb" src={f.image} alt="" />
          <button className="btn small red" type="button" onClick={() => set({ image: '', blob: null })}>Remove picture</button>
        </div>
      ) : null}
      <div className="row" style={{ marginTop: 14 }}>
        <button className="btn" type="button" disabled={busy} onClick={save}>Save club settings</button>
      </div>
      <Msg {...(local || {})} />
    </div>
  );
}

const bucket = (c) => (c.earned > c.delivered ? 'due' : (c.earned > 0 ? 'done' : 'none'));

export default function CustomersTab({ setMsg }) {
  const [rows, setRows] = useState(null);
  const [filter, setFilter] = useState('all');
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    try { setRows(await getCustomers()); setMsg(null); } catch (e) { setMsg({ kind: 'bad', text: 'Could not load customers: ' + e.message }); }
  }, [setMsg]);
  useEffect(() => { load(); }, [load]);

  async function mark(c, d) {
    try {
      const r = await markReward(c.id, d);
      setRows((list) => list.map((x) => (x.id === c.id ? { ...x, earned: r.earned, delivered: r.delivered } : x)));
    } catch (e) { setMsg({ kind: 'bad', text: 'Could not save: ' + e.message }); }
  }

  async function pin(c) {
    const p = window.prompt('New 4-number PIN for ' + c.name + ':');
    if (p === null) return;
    if (!/^[0-9]{4}$/.test(p.trim())) { window.alert('The PIN must be exactly 4 numbers.'); return; }
    try { await resetPin(c.id, p.trim()); window.alert('Done. Tell ' + c.name + ' the new PIN. Their old logins were signed out.'); }
    catch (e) { setMsg({ kind: 'bad', text: 'Could not reset: ' + e.message }); }
  }

  async function remove(c) {
    if (!window.confirm('Delete the account of ' + c.name + '?\nTheir pack count is lost. Their scanned codes stay used.')) return;
    try { await deleteCustomer(c.id); setRows((list) => list.filter((x) => x.id !== c.id)); }
    catch (e) { setMsg({ kind: 'bad', text: 'Could not delete: ' + e.message }); }
  }

  function csv() {
    const lines = [['Name', 'Phone', 'Packs', 'Rewards earned', 'Rewards delivered', 'Joined'].map(csvCell).join(',')];
    rows.forEach((c) => lines.push([c.name, '+' + c.phone, c.packs, c.earned, c.delivered, fmtDate(c.joined)].map(csvCell).join(',')));
    downloadFile('\ufeff' + lines.join('\r\n'), 'munchmix_customers.csv', 'text/csv;charset=utf-8');
  }

  const counts = { all: 0, due: 0, done: 0, none: 0 };
  (rows || []).forEach((c) => { counts.all++; counts[bucket(c)]++; });
  const needle = q.trim().toLowerCase();
  const shown = (rows || []).filter((c) => (filter === 'all' || bucket(c) === filter)
    && (!needle || (c.name + ' ' + c.phone).toLowerCase().indexOf(needle) >= 0));

  return (
    <section>
      <ClubSettings setMsg={setMsg} />
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>Customers</h2>
        {rows ? <button className="btn small alt" type="button" onClick={csv}>Download list (CSV)</button> : null}
      </div>
      {!rows ? <p className="muted">Loading…</p> : (
        <>
          <div className="chips">
            {[['all', 'All'], ['due', 'Reward to deliver'], ['done', 'Reward delivered'], ['none', 'Still collecting']].map(([id, label]) => (
              <button key={id} type="button" className={'chip' + (filter === id ? ' on' : '')} onClick={() => setFilter(id)}>{label} ({counts[id]})</button>
            ))}
          </div>
          <input type="search" placeholder="Search name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
          <div className="card" style={{ marginTop: 14 }}>
            {shown.length ? shown.map((c) => (
              <div className="item" key={c.id}>
                <div className="grow">
                  <div><b>{c.name}</b> {c.earned > c.delivered ? <span className="tag r">reward to deliver ×{c.earned - c.delivered}</span> : null}</div>
                  <div className="muted">+{c.phone} · {c.packs} packs · rewards {c.delivered}/{c.earned} delivered · joined {fmtDate(c.joined)}</div>
                  <div className="row" style={{ marginTop: 8 }}>
                    <a className="btn small alt" href={'https://wa.me/' + c.phone} target="_blank" rel="noopener noreferrer">WhatsApp</a>
                    <a className="btn small alt" href={'tel:+' + c.phone}>Call</a>
                    {c.earned > c.delivered ? <button className="btn small yel" type="button" onClick={() => mark(c, 1)}>Mark 1 delivered</button> : null}
                    {c.delivered > 0 ? <button className="btn small alt" type="button" onClick={() => mark(c, -1)}>Undo 1</button> : null}
                    <button className="btn small alt" type="button" onClick={() => pin(c)}>Reset PIN</button>
                    <button className="btn small red" type="button" onClick={() => remove(c)}>Delete</button>
                  </div>
                </div>
              </div>
            )) : <p className="muted">Nobody here yet.</p>}
          </div>
        </>
      )}
    </section>
  );
}
