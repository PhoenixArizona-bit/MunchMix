// Runs after the React build. Fills in your real site address for search engines
// and writes robots.txt and sitemap.xml. Safe: if anything is missing it still finishes.
const fs = require('fs');
const path = require('path');

const build = path.join(__dirname, '..', 'build');
let site = (process.env.REACT_APP_SITE_URL || '').trim();
if (!site && process.env.VERCEL_PROJECT_PRODUCTION_URL) site = 'https://' + process.env.VERCEL_PROJECT_PRODUCTION_URL.trim();
if (!site && process.env.VERCEL_URL) site = 'https://' + process.env.VERCEL_URL.trim();
site = site.replace(/\/+$/, '');
if (site && !/^https?:\/\//i.test(site)) site = 'https://' + site;

try {
  const file = path.join(build, 'index.html');
  let html = fs.readFileSync(file, 'utf8');
  if (site) {
    html = html.split('__SITE_URL__').join(site);
  } else {
    html = html
      .replace(/<link rel="canonical"[^>]*>\s*/g, '')
      .replace(/<meta property="og:url"[^>]*>\s*/g, '')
      .replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>\s*/g, '')
      .split('__SITE_URL__').join('');
  }
  fs.writeFileSync(file, html);

  const robots = ['User-agent: *', 'Allow: /', 'Disallow: /admin', 'Disallow: /c/', ''];
  if (site) robots.push('Sitemap: ' + site + '/sitemap.xml', '');
  fs.writeFileSync(path.join(build, 'robots.txt'), robots.join('\n'));

  if (site) {
    const today = new Date().toISOString().slice(0, 10);
    fs.writeFileSync(path.join(build, 'sitemap.xml'),
      '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
      '  <url><loc>' + site + '/</loc><lastmod>' + today + '</lastmod><changefreq>weekly</changefreq><priority>1.0</priority></url>\n</urlset>\n');
  }
  console.log('SEO files done. Site address used: ' + (site || '(none found - canonical tags removed)'));
} catch (e) {
  console.log('SEO step skipped: ' + e.message);
}
