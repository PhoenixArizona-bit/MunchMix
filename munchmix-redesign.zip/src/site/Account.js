import React, { useCallback, useEffect, useRef, useState } from 'react';
import { supabase, LIVE } from '../supabaseClient';

const KEY = 'mm_session';
const getSess = () => { try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; } };
const putSess = (v) => { try { if (v) localStorage.setItem(KEY, v); else localStorage.removeItem(KEY); } catch (e) { /* ignore */ } };

/* keeps the logged-in customer and the club settings */
export function useAccount() {
  const [st, setSt] = useState({ ready: !LIVE, customer: null, loyalty: null });
  const sess = useRef(getSess());

  useEffect(() => {
    if (!LIVE) return undefined;
    let alive = true;
    (async () => {
      let customer = null;
      let loyalty = null;
      try {
        if (sess.current) {
          const { data } = await supabase.rpc('customer_me', { p_session: sess.current });
          if (data && data.status === 'ok') { customer = data.customer; loyalty = data.loyalty; }
          else if (data && data.status === 'no_session') { sess.current = ''; putSess(''); }
        }
        if (!loyalty) {
          const { data } = await supabase.rpc('get_loyalty');
          if (data) loyalty = data;
        }
      } catch (e) { /* offline: show the login form */ }
      if (alive) setSt({ ready: true, customer, loyalty });
    })();
    return () => { alive = false; };
  }, []);

  const enter = useCallback((data) => {
    sess.current = data.session;
    putSess(data.session);
    setSt({ ready: true, customer: data.customer, loyalty: data.loyalty });
  }, []);

  const signup = useCallback(async (name, phone, pin) => {
    const { data, error } = await supabase.rpc('customer_signup', { p_name: name, p_phone: phone, p_pin: pin });
    if (error) throw error;
    if (data.status === 'ok') enter(data);
    return data.status;
  }, [enter]);

  const login = useCallback(async (phone, pin) => {
    const { data, error } = await supabase.rpc('customer_login', { p_phone: phone, p_pin: pin });
    if (error) throw error;
    if (data.status === 'ok') enter(data);
    return data.status;
  }, [enter]);

  const logout = useCallback(async () => {
    const s = sess.current;
    sess.current = '';
    putSess('');
    setSt((x) => ({ ...x, customer: null }));
    try { await supabase.rpc('customer_logout', { p_session: s }); } catch (e) { /* ignore */ }
  }, []);

  const update = useCallback((customer, loyalty) => {
    setSt((x) => ({ ...x, customer: customer || x.customer, loyalty: loyalty || x.loyalty }));
  }, []);

  const expire = useCallback(() => {
    sess.current = '';
    putSess('');
    setSt((x) => ({ ...x, customer: null }));
  }, []);

  const session = useCallback(() => sess.current, []);

  return { ...st, signup, login, logout, update, expire, session };
}

/* "install this site" button for Chrome / Android */
export function useInstall() {
  const [evt, setEvt] = useState(null);
  const [installed, setInstalled] = useState(() => (
    (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true
  ));
  useEffect(() => {
    const before = (e) => { e.preventDefault(); setEvt(e); };
    const done = () => { setInstalled(true); setEvt(null); };
    window.addEventListener('beforeinstallprompt', before);
    window.addEventListener('appinstalled', done);
    return () => { window.removeEventListener('beforeinstallprompt', before); window.removeEventListener('appinstalled', done); };
  }, []);
  const install = useCallback(async () => {
    if (!evt) return;
    evt.prompt();
    try { await evt.userChoice; } catch (e) { /* ignore */ }
    setEvt(null);
  }, [evt]);
  const ua = navigator.userAgent || '';
  const ios = /iphone|ipad|ipod/i.test(ua) && !installed;
  return { canInstall: Boolean(evt) && !installed, install, ios, installed };
}

export function InstallButton({ inst, className }) {
  if (!inst.canInstall) return null;
  return <button type="button" className={className || 'btn btn-secondary'} onClick={inst.install}>⬇ Install app</button>;
}

/* ------------------------------------------------------ sign up / log in */
export function AccountForm({ account, hasCode }) {
  const [mode, setMode] = useState('signup');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setMsg({ kind: 'info', text: 'One moment…' });
    try {
      const s = mode === 'signup' ? await account.signup(name, phone, pin) : await account.login(phone, pin);
      if (s === 'ok') return;
      const text = {
        bad_name: 'Please enter your name (at least 2 letters).',
        bad_phone: 'Please enter a valid phone number, like 0300 1234567.',
        bad_pin: 'Your PIN must be exactly 4 numbers.',
        exists: 'This number already has an account. Please log in instead.',
        wrong: 'Wrong phone number or PIN. Please try again.',
        rate_limited: 'Too many tries. Please wait a little and try again.',
      }[s] || 'Something went wrong. Please try again.';
      if (s === 'exists') setMode('login');
      setMsg({ kind: 'warn', text });
    } catch (err) {
      setMsg({ kind: 'warn', text: 'Could not reach the rewards server. Check your internet and try again.' });
    }
    setBusy(false);
  }

  return (
    <form className="acct" onSubmit={submit} noValidate>
      <div className="acct-tabs" role="tablist">
        <button type="button" className={mode === 'signup' ? 'on' : ''} onClick={() => { setMode('signup'); setMsg(null); }}>Create account</button>
        <button type="button" className={mode === 'login' ? 'on' : ''} onClick={() => { setMode('login'); setMsg(null); }}>Log in</button>
      </div>
      <p className="scan-lead">
        {hasCode
          ? 'We found the code from your pack. Create an account or log in, then tap "Check my prize".'
          : (mode === 'signup' ? 'Make a free account so every pack you scan is counted for you.' : 'Welcome back! Log in to see your packs.')}
      </p>
      <div className="prize-form">
        {mode === 'signup' ? (
          <>
            <label htmlFor="acName">Your name</label>
            <input id="acName" type="text" maxLength={60} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
          </>
        ) : null}
        <label htmlFor="acPhone">Phone / WhatsApp number</label>
        <input id="acPhone" type="tel" inputMode="tel" maxLength={20} autoComplete="tel" placeholder="03XX XXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <label htmlFor="acPin">{mode === 'signup' ? 'Make a 4-number PIN' : 'Your 4-number PIN'}</label>
        <input id="acPin" type="password" inputMode="numeric" pattern="[0-9]*" maxLength={4} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'} placeholder="••••" value={pin} onChange={(e) => setPin(e.target.value.replace(/[^0-9]/g, ''))} />
        <button className="btn btn-scan" type="submit" disabled={busy}>{mode === 'signup' ? 'Create my account' : 'Log in'}</button>
        {msg ? <div className={'claim-result show ' + msg.kind} role="status">{msg.text}</div> : null}
        <p className="help">{mode === 'signup'
          ? 'The PIN keeps your packs safe, so nobody else can use your number. We only use your details to contact you about prizes.'
          : 'Forgot your PIN? Contact the Munch Mix team and we will reset it for you.'}</p>
      </div>
    </form>
  );
}

/* ----------------------------------------------- progress toward the big prize */
export function ClubCard({ customer, loyalty, onLogout }) {
  const target = (loyalty && loyalty.target) || 100;
  const enabled = !loyalty || loyalty.enabled;
  const packs = customer.packs || 0;
  const inRound = packs > 0 && packs % target === 0 ? target : packs % target;
  const left = target - inRound;
  const prize = (loyalty && loyalty.prize) || {};
  const due = (customer.rewards_earned || 0) - (customer.rewards_delivered || 0);
  const showImg = prize.image && /^https:\/\//i.test(prize.image);
  return (
    <div className="club">
      <div className="club-top">
        <div><small>Hi,</small><strong>{customer.name}</strong></div>
        <button type="button" className="link-btn" onClick={onLogout}>Log out</button>
      </div>
      {enabled ? (
        <>
          <div className="club-count"><b>{inRound}</b><span> / {target} packs</span></div>
          <div className="bar" role="progressbar" aria-valuemin={0} aria-valuemax={target} aria-valuenow={inRound}><i style={{ width: Math.round((inRound / target) * 100) + '%' }} /></div>
          <p className="club-note">
            {left === target
              ? 'Scan your first pack to start. Every pack counts toward your guaranteed prize.'
              : (left === 0
                ? 'You reached ' + target + ' packs!'
                : left + ' more pack' + (left === 1 ? '' : 's') + ' to your guaranteed prize.')}
          </p>
          {prize.name ? (
            <div className="club-prize">
              {showImg ? <img src={prize.image} alt={prize.name} /> : <span className="club-gift">🎁</span>}
              <div><small>Guaranteed prize at {target} packs</small><strong>{prize.name}</strong>{prize.description ? <em>{prize.description}</em> : null}</div>
            </div>
          ) : null}
          {due > 0 ? (
            <div className="claim-result show info">🎉 You unlocked {due > 1 ? due + ' rewards' : 'your reward'}! The Munch Mix team will contact you on +{customer.phone}.</div>
          ) : null}
          {customer.rewards_delivered > 0 ? <p className="help">Rewards already delivered to you: {customer.rewards_delivered}</p> : null}
        </>
      ) : <p className="club-note">Total packs scanned: {packs}</p>}
    </div>
  );
}

/* shown before login so visitors see why to join */
export function ClubTeaser({ loyalty }) {
  if (!loyalty || !loyalty.enabled) return null;
  const prize = loyalty.prize || {};
  return (
    <div className="club-teaser">
      <b>Scan {loyalty.target} packs = a guaranteed prize</b>
      {prize.name ? <span>{prize.name}{prize.description ? ' · ' + prize.description : ''}</span> : null}
    </div>
  );
}
