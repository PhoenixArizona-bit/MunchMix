import React from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/rozha-one/400.css';
import '@fontsource/mukta/400.css';
import '@fontsource/mukta/600.css';
import '@fontsource/mukta/800.css';
import App from './App';

createRoot(document.getElementById('root')).render(<App />);

// lets phones install the site as an app, and keeps it working on a weak connection
if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => { /* not a problem: the site still works */ });
  });
}
