import { createClient } from '@supabase/supabase-js';

// These two values come from Vercel > Settings > Environment Variables.
const url = (process.env.REACT_APP_SUPABASE_URL || '').trim().replace(/\/+$/, '');
const key = (process.env.REACT_APP_SUPABASE_ANON_KEY || '').trim();

export const LIVE = Boolean(url && key);
export const supabase = LIVE ? createClient(url, key) : null;
