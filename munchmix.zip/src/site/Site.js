import React, { useCallback, useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import './site.css';
import { supabase, LIVE } from '../supabaseClient';
import heroCorner from './assets/hero-corner.webp';
import stageSnacks from './assets/stage-snacks.webp';
import flavourBowl from './assets/flavour-bowl.webp';
import flavourChilli from './assets/flavour-chilli.webp';
import flavourChai from './assets/flavour-chai.webp';
import scanArt from './assets/scan-art.webp';
import archArt from './assets/arch-art.webp';

const TOKEN_RE = /^[A-Za-z0-9_-]{6,40}$/;

// accepts a plain code, or a link like https://site/c/CODE or https://site/?c=CODE
function getToken(raw) {
  const v = String(raw).trim();
  try {
    const u = new URL(v);
    const c = u.searchParams.get('c');
    if (c) return c.trim();
    const m = u.pathname.match(/\/c\/([A-Za-z0-9_-]{6,40})\/?$/i);
    if (m) return m[1];
  } catch (e) {
    /* not a link: use as is */
  }
  return v;
}

function tokenFromLocation() {
  try {
    const u = new URL(window.location.href);
    let tok = u.searchParams.get('c') || '';
    if (!tok) {
      const m = u.pathname.match(/\/c\/([A-Za-z0-9_-]{6,40})\/?$/i);
      if (m) tok = m[1];
    }
    return TOKEN_RE.test(tok) ? tok : '';
  } catch (e) {
    return '';
  }
}

/* ---------------------------------------------------------------- header */
function Header() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <header>
      <div className="wrap nav">
        <a className="brand" href="#home" aria-label="Munch Mix home">
          <span className="brand-mark">✿</span>
          <span>MUNCH <span>MIX</span></span>
        </a>
        <nav className="navlinks" aria-label="Main">
          <a href="#flavours">The crunch</a>
          <a href="#rewards">Mix Rewards</a>
          <a href="#story">Our vibe</a>
          <a className="nav-cta" href="#rewards">Scan &amp; win ↗</a>
        </nav>
        <button
          className="mobile-menu"
          type="button"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open ? 'true' : 'false'}
          aria-controls="menuPanel"
          onClick={() => setOpen(!open)}
        >
          {open ? '✕' : '☰'}
        </button>
      </div>
      <nav className={'menu-panel' + (open ? ' open' : '')} id="menuPanel" aria-label="Mobile" onClick={(e) => { if (e.target.closest('a')) close(); }}>
        <a href="#flavours">The crunch</a>
        <a href="#rewards">Mix Rewards</a>
        <a href="#story">Our vibe</a>
        <a className="nav-cta" href="#rewards">Scan &amp; win ✦</a>
      </nav>
    </header>
  );
}

/* ------------------------------------------------------------------ hero */
function Hero() {
  return (
    <section className="hero" id="home">
      <img className="hero-corner" src={heroCorner} alt="" aria-hidden="true" />
      <div className="wrap hero-grid">
        <div>
          <div className="eyebrow">A little desi. A lot of masti.</div>
          <h1>BIG CRUNCH.<br /><em>BOLD MASTI.</em></h1>
          <p className="hero-copy">Your favourite snack-time chaos, wrapped in colour. Munch Mix brings the desi crunch with a playful twist — perfect for sharing, or absolutely not sharing.</p>
          <div className="hero-actions">
            <a className="btn btn-primary" href="#flavours">Meet the mix <span>↘</span></a>
            <a className="btn btn-secondary" href="#rewards">Unlock rewards ✦</a>
          </div>
          <div className="mini-proof">
            <div className="faces"><span className="face">✿</span><span className="face">★</span><span className="face">☻</span></div>
            <span>Good snacks. Good scenes. Great crunch.</span>
          </div>
        </div>
        <div className="art-stage" aria-label="Illustrated Munch Mix snack pouch">
          <img className="stage-snacks" src={stageSnacks} alt="" aria-hidden="true" />
          <div className="sunburst" />
          <div className="flower"><i /><i /><i /><i /><i /><b /></div>
          <div className="snack-pouch">
            <div className="pouch-top" />
            <div className="pouch-label"><small>FULL OF</small><strong>MUNCH<br />MIX</strong><b>DESI CRUNCH CLUB</b></div>
            <div className="snack-bowl"><span className="snack" /><span className="snack" /><span className="snack" /></div>
            <div className="pouch-foot">CRUNCH • CHAT • REPEAT</div>
          </div>
          <div className="sticker"><div><strong>100%</strong> MASTI<br />MODE</div></div>
          <div className="float-chip chip-left">DESI ✦ SWAG</div>
          <div className="float-chip chip-right">CRUNCH CLUB ↗</div>
        </div>
      </div>
    </section>
  );
}

function Ticker() {
  const line = 'FULL OF MASTI ✿ BIG CRUNCH ENERGY ★ SHARE THE SNACKS ✿ FULL OF MASTI ★ BIG CRUNCH ENERGY ✿ SHARE THE SNACKS ★';
  const parts = line.split(/([✿★])/).filter(Boolean);
  const span = (key) => (
    <span key={key}>
      {parts.map((p, i) => (p === '✿' || p === '★' ? <b key={i}>{p}</b> : <React.Fragment key={i}>{p}</React.Fragment>))}
    </span>
  );
  return (
    <div className="ticker" aria-hidden="true">
      <div className="ticker-inner">{span('a')}{span('b')}</div>
    </div>
  );
}

/* --------------------------------------------------------------- flavours */
function Flavours() {
  const items = [
    { n: '01 / The classic', a: 'DESI', b: 'CLASSIC', p: 'The familiar, salty, snacky kind of happiness.', img: flavourBowl, alt: 'Bowl of nimko snack mix' },
    { n: '02 / The loud one', a: 'MASALA', b: 'MANIA', p: 'A bold little kick for your big snack energy.', img: flavourChilli, alt: 'Red chilli with spice swirls' },
    { n: '03 / The chill one', a: 'CHAI-TIME', b: 'CRUNCH', p: 'Your tea break just found its crunchy bestie.', img: flavourChai, alt: 'Chai cup with snacks' },
  ];
  return (
    <section id="flavours">
      <div className="wrap">
        <div className="section-head">
          <div>
            <div className="kicker">Meet your munch crew</div>
            <h2>THREE MOODS.<br />ONE BIG CRUNCH.</h2>
          </div>
          <p className="section-desc">From chai-time gossip to late-night study breaks, there’s a Munch Mix mood for every kind of scene.</p>
        </div>
        <div className="flavours">
          {items.map((it) => (
            <article className="flavour" key={it.n}>
              <small>{it.n}</small>
              <span className="number">✦ MM</span>
              <div>
                <h3>{it.a}<br />{it.b}</h3>
                <p>{it.p}</p>
              </div>
              <div className="flavour-art photo"><img src={it.img} alt={it.alt} loading="lazy" /></div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------- winner box */
function PrizeBox({ token, prize, welcomeBack }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [msg, setMsg] = useState(null);
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current && ref.current.scrollIntoView) ref.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, []);

  async function send() {
    setSending(true);
    setMsg({ kind: 'info', text: 'Sending…' });
    try {
      const { data: r, error } = await supabase.rpc('claim_prize', { p_token: token, p_name: name, p_phone: phone });
      if (error) throw error;
      if (r.status === 'claimed') { setDone(true); return; }
      if (r.status === 'bad_name') setMsg({ kind: 'warn', text: 'Please enter your name.' });
      else if (r.status === 'bad_phone') setMsg({ kind: 'warn', text: 'Please enter a valid phone number.' });
      else if (r.status === 'already_claimed') setMsg({ kind: 'warn', text: 'Details for this code were already saved.' });
      else setMsg({ kind: 'warn', text: 'Something went wrong. Please try again.' });
    } catch (e) {
      setMsg({ kind: 'warn', text: 'Could not reach the rewards server. Check your internet and try again.' });
    }
    setSending(false);
  }

  if (done) {
    return (
      <div className="prize-box" ref={ref}>
        <h3 className="prize-title">Thank you!</h3>
        <p className="prize-desc">Your details are saved. The Munch Mix team will contact you about your prize.</p>
      </div>
    );
  }
  const showImg = prize.image && /^https:\/\//i.test(prize.image);
  return (
    <div className="prize-box" ref={ref}>
      <h3 className="prize-title">{welcomeBack ? 'Welcome back! Finish claiming your prize' : 'You won!'}</h3>
      {showImg ? <img className="prize-img" src={prize.image} alt={prize.name || 'Prize'} /> : null}
      <div className="prize-name">{prize.name || 'Prize'}</div>
      {prize.description ? <p className="prize-desc">{prize.description}</p> : null}
      <div className="prize-form">
        <label htmlFor="pzName">Your name</label>
        <input id="pzName" type="text" maxLength={60} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
        <label htmlFor="pzPhone">Phone / WhatsApp number</label>
        <input id="pzPhone" type="tel" inputMode="tel" maxLength={20} autoComplete="tel" placeholder="03XX XXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <button className="btn btn-scan" type="button" disabled={sending} onClick={send}>Send my details</button>
        {msg ? <div className={'claim-result show ' + msg.kind} role="status">{msg.text}</div> : null}
        <p className="help">We use your name and number to contact you about your prize.</p>
      </div>
    </div>
  );
}

/* ----------------------------------------------- rewards + QR scanner */
function Rewards() {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const runningRef = useRef(false);
  const busyRef = useRef(false);
  const timerRef = useRef(0);
  const detectorRef = useRef(null);
  const canvasRef = useRef(null);
  const checkingRef = useRef(false);
  const onCodeRef = useRef(null);

  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState(null);
  const [prize, setPrize] = useState(null);
  const [linkToken, setLinkToken] = useState(tokenFromLocation);

  useEffect(() => {
    if ('BarcodeDetector' in window) {
      try { detectorRef.current = new window.BarcodeDetector({ formats: ['qr_code'] }); } catch (e) { detectorRef.current = null; }
    }
  }, []);

  const stopCam = useCallback(() => {
    runningRef.current = false;
    clearTimeout(timerRef.current);
    if (streamRef.current) { streamRef.current.getTracks().forEach((t) => t.stop()); streamRef.current = null; }
    if (videoRef.current) videoRef.current.srcObject = null;
    setScanning(false);
  }, []);

  useEffect(() => {
    const onHide = () => { if (document.hidden && runningRef.current) stopCam(); };
    document.addEventListener('visibilitychange', onHide);
    return () => { document.removeEventListener('visibilitychange', onHide); stopCam(); };
  }, [stopCam]);

  const decode = useCallback(async (source, w, h, both) => {
    if (detectorRef.current) {
      try {
        const r = await detectorRef.current.detect(source);
        if (r && r.length && r[0].rawValue) return r[0].rawValue;
      } catch (e) { /* fall back to the library */ }
    }
    if (!canvasRef.current) canvasRef.current = document.createElement('canvas');
    const canvas = canvasRef.current;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(source, 0, 0, w, h);
    const d = ctx.getImageData(0, 0, w, h);
    const c = jsQR(d.data, w, h, { inversionAttempts: both ? 'attemptBoth' : 'dontInvert' });
    return c ? c.data : null;
  }, []);

  const checkCode = useCallback(async (raw) => {
    const token = getToken(raw);
    setPrize(null);
    if (!LIVE) {
      let v = String(raw).trim();
      if (v.length > 80) v = v.slice(0, 77) + '…';
      setResult({ kind: 'info', text: 'QR scanned. It says: "' + v + '". This is a design demo, so the code was NOT checked or redeemed.' });
      return;
    }
    if (checkingRef.current) return;
    checkingRef.current = true;
    setResult({ kind: 'info', text: 'Checking your code…' });
    try {
      const { data: r, error } = await supabase.rpc('redeem_code', { p_token: token });
      if (error) throw error;
      if (r.status === 'ok') {
        if (r.prize) { setResult(null); setPrize({ token, prize: r.prize, welcomeBack: false }); }
        else setResult({ kind: 'info', text: 'Thanks for scanning! This pack is not a winner this time. Try your next pack.' });
      } else if (r.status === 'pending_claim' && r.prize) {
        setResult(null);
        setPrize({ token, prize: r.prize, welcomeBack: true });
      } else if (r.status === 'used') setResult({ kind: 'warn', text: 'This code has already been used.' });
      else if (r.status === 'invalid') setResult({ kind: 'warn', text: 'We could not find this code. Please check your pack and try again.' });
      else if (r.status === 'rate_limited') setResult({ kind: 'warn', text: 'Too many tries. Please wait a few minutes and try again.' });
      else setResult({ kind: 'warn', text: 'Something went wrong. Please try again in a moment.' });
    } catch (e) {
      setResult({ kind: 'warn', text: 'Could not reach the rewards server. Check your internet and try again.' });
    }
    checkingRef.current = false;
  }, []);

  useEffect(() => { onCodeRef.current = checkCode; }, [checkCode]);

  const tick = useCallback(async () => {
    if (!runningRef.current) return;
    const video = videoRef.current;
    if (video && video.readyState >= 2 && video.videoWidth && !busyRef.current) {
      busyRef.current = true;
      const sc = Math.min(1, 640 / video.videoWidth);
      const w = Math.round(video.videoWidth * sc);
      const h = Math.round(video.videoHeight * sc);
      let val = null;
      try { val = await decode(video, w, h, false); } catch (e) { /* try again */ }
      busyRef.current = false;
      if (val) {
        stopCam();
        if (navigator.vibrate) navigator.vibrate(60);
        if (onCodeRef.current) onCodeRef.current(val);
        return;
      }
    }
    timerRef.current = setTimeout(tick, 130);
  }, [decode, stopCam]);

  async function startCam() {
    setResult(null);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setResult({ kind: 'warn', text: 'This browser cannot open the camera here. Please use "Take or upload a photo" instead.' });
      return;
    }
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
    } catch (err) {
      setResult({
        kind: 'warn',
        text: err && err.name === 'NotAllowedError'
          ? 'Camera access is blocked. Allow the camera for this site, or use "Take or upload a photo" instead.'
          : 'Could not start the camera. Please use "Take or upload a photo" instead.',
      });
      return;
    }
    streamRef.current = stream;
    setScanning(true);
    const video = videoRef.current;
    video.srcObject = stream;
    try { await video.play(); } catch (e) { /* the browser may start it by itself */ }
    runningRef.current = true;
    tick();
  }

  function onPhoto(ev) {
    const f = ev.target.files && ev.target.files[0];
    ev.target.value = '';
    if (!f) return;
    stopCam();
    setResult({ kind: 'info', text: 'Reading your photo…' });
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = async () => {
      let val = null;
      try {
        const widths = [1400, 800, 2000];
        for (let i = 0; i < widths.length && !val; i++) {
          const sc = Math.min(1, widths[i] / Math.max(img.naturalWidth, img.naturalHeight));
          val = await decode(img, Math.max(1, Math.round(img.naturalWidth * sc)), Math.max(1, Math.round(img.naturalHeight * sc)), true);
        }
      } catch (e) { /* no code found */ }
      URL.revokeObjectURL(url);
      if (val) checkCode(val);
      else setResult({ kind: 'warn', text: 'No QR code found in that photo. Move closer, use good light and keep the code flat, then try again.' });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      setResult({ kind: 'warn', text: 'That file could not be read as a photo. Please try another one.' });
    };
    img.src = url;
  }

  function useLinkCode() {
    const tok = linkToken;
    setLinkToken('');
    try {
      window.history.replaceState(null, '', window.location.pathname.replace(/\/c\/[^/]+\/?$/i, '/') + window.location.hash);
    } catch (e) { /* ignore */ }
    checkCode(tok);
  }

  // opened from a QR link: bring the visitor to the scanner
  useEffect(() => {
    if (!tokenFromLocation()) return undefined;
    const t = setTimeout(() => {
      const r = document.getElementById('rewards');
      if (r) r.scrollIntoView({ behavior: 'smooth' });
    }, 300);
    return () => clearTimeout(t);
  }, []);

  return (
    <section className="rewards" id="rewards">
      <div className="wrap rewards-grid">
        <div className="r-head">
          <div className="kicker">Your snack. Your score.</div>
          <h2>SCAN IT.<br />CLAIM IT.<br />GET REWARDED.</h2>
          <p>Every participating pack can bring you closer to Munch Mix rewards. Find the QR code on your pack and scan it with your phone.</p>
        </div>

        <div className="claim-card" id="scanCard">
          <div className="card-top"><strong>Mix Rewards Club</strong><span className="pill">Early access</span></div>
          <p className="scan-lead">Point your camera at the QR code on your pack.</p>

          {linkToken ? (
            <div className="link-box">
              <p>We found the code from your pack's QR.</p>
              <button className="btn btn-scan" type="button" onClick={useLinkCode}>Check my prize</button>
            </div>
          ) : null}

          <div className="scan-actions">
            <button className="btn btn-scan" type="button" disabled={scanning} onClick={startCam}>📷 Scan QR code</button>
            <label className="btn btn-photo" htmlFor="photoIn">🖼 Take or upload a photo</label>
            <input id="photoIn" type="file" accept="image/*" capture="environment" hidden onChange={onPhoto} />
          </div>

          <div className={'scanner' + (scanning ? ' on' : '')}>
            <div className="scan-view">
              <video ref={videoRef} playsInline muted />
              <div className="scan-frame" />
              <div className="scan-hint">Keep the QR inside the box</div>
            </div>
            <button className="btn btn-stop" type="button" onClick={stopCam}>Stop camera</button>
          </div>

          {result ? <div className={'claim-result show ' + result.kind} role="status" aria-live="polite">{result.text}</div> : null}
          {prize ? <PrizeBox key={prize.token} token={prize.token} prize={prize.prize} welcomeBack={prize.welcomeBack} /> : null}

          <p className="help">Tip: good light, hold steady, fill the box with the code.</p>
          {!LIVE ? (
            <p className="demo-note">DESIGN DEMO: the scanner reads the QR, but this page does not check or redeem codes yet. A live rewards program needs a secure database and server-side one-time validation.</p>
          ) : null}
        </div>

        <div className="r-extra">
          <div className="steps">
            <div className="step"><span className="step-num">1</span><span>Grab a participating Munch Mix pack.</span></div>
            <div className="step"><span className="step-num">2</span><span>Find the QR code inside or under the label.</span></div>
            <div className="step"><span className="step-num">3</span><span>Scan it and follow the reward instructions.</span></div>
          </div>
          <img className="scan-art" src={scanArt} alt="Hand scanning a Munch Mix pack with a phone" loading="lazy" />
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------ story + footer */
function Story() {
  return (
    <section className="story" id="story">
      <div className="wrap story-grid">
        <div className="ornament-panel">
          <img className="arch-art" src={archArt} alt="" loading="lazy" />
          <div className="ornament-word">FULL OF MASTI!</div>
        </div>
        <div className="story-copy">
          <div className="kicker" style={{ color: 'var(--yellow)' }}>A little tradition. A lot of attitude.</div>
          <h2>DESI ROOTS.<br /><em>FRESH ENERGY.</em></h2>
          <p>Munch Mix brings colourful South Asian patterns, street-snack spirit and playful modern design together. Familiar at heart, impossible to ignore on the shelf.</p>
          <p>We’re building a snack brand that feels joyful, bold and made for sharing good moments.</p>
          <a className="btn btn-primary" href="#home">Back to the top ↑</a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer>
      <div className="wrap footer-row">
        <a className="brand" href="#home"><span className="brand-mark">✿</span><span>MUNCH <span>MIX</span></span></a>
        <div className="footer-copy">© {new Date().getFullYear()} Munch Mix. Made for the masti.</div>
        <div className="footer-links"><a href="#flavours">The crunch</a><a href="#rewards">Rewards</a><a href="#story">Our vibe</a></div>
      </div>
    </footer>
  );
}

/* ------------------------------------------------------------------ page */
export default function Site() {
  const [away, setAway] = useState(false);

  useEffect(() => {
    document.title = 'Munch Mix — Full of Masti';
    const el = document.getElementById('rewards');
    if (!el || !('IntersectionObserver' in window)) return undefined;
    const io = new IntersectionObserver((en) => setAway(en[0].isIntersecting), { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <>
      <div className="topbar">Crunch loud. Share the masti. &nbsp; ✦ &nbsp; Made for your snack breaks</div>
      <Header />
      <main>
        <Hero />
        <Ticker />
        <Flavours />
        <Rewards />
        <Story />
      </main>
      <Footer />
      <a className={'sticky-cta' + (away ? ' away' : '')} href="#rewards">📷 Scan &amp; win</a>
    </>
  );
}
