import React, { Suspense, lazy } from 'react';

// Each page loads on its own, so their styles never mix.
const Site = lazy(() => import('./site/Site'));
const Admin = lazy(() => import('./admin/Admin'));

export default function App() {
  const path = window.location.pathname.replace(/\/+$/, '').toLowerCase();
  const isAdmin = path === '/admin' || path.indexOf('/admin/') === 0;
  return (
    <Suspense fallback={<div style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>Loading…</div>}>
      {isAdmin ? <Admin /> : <Site />}
    </Suspense>
  );
}
