import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Msg from './Msg';
import prevPageSrc from './assets/prev-page.jpg';
import prevHdrSrc from './assets/prev-hdr.jpg';
import { addCodes, getBatchTokens } from './api';
import {
  buildPdf, checkTpl, csvCell, downloadFile, loadSavedTpl, normBase, paintQr, qrPlan, randBatchSuffix,
  randInt, randToken, saveTpl, verdict,
} from './qrpdf';

const DEFAULTS = { siteUrl: '', mode: 'keep', ecc: 'auto', sheets: 5, perFile: 20, qty: {} };

function loadSettings() {
  try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem('mm_settings') || '{}') }; } catch (e) { return { ...DEFAULTS }; }
}

export default function PrintTab({ prizes, stats, onChanged, reprint, onReprintDone }) {
  const [settings, setSettings] = useState(loadSettings);
  const [tpl, setTpl] = useState({ bytes: null, info: null, note: null });
  const [msg, setMsg] = useState(null);
  const [progress, setProgress] = useState(null);
  const [busy, setBusy] = useState(false);
  const [files, setFiles] = useState(null); // { batch, items }
  const [partBusy, setPartBusy] = useState(-1);
  const [imgs, setImgs] = useState({ page: null, hdr: null });
  const pendingRef = useRef(null);
  const pageCv = useRef(null);
  const hdrCv = useRef(null);
  const filesRef = useRef(null);

  const update = (patch) => setSettings((s) => {
    const n = { ...s, ...patch };
    try { localStorage.setItem('mm_settings', JSON.stringify(n)); } catch (e) { /* ignore */ }
    return n;
  });

  const activePrizes = useMemo(() => prizes.filter((p) => p.active), [prizes]);
  const sheets = Math.max(1, Math.min(1000, Math.floor(Number(settings.sheets) || 1)));
  const perFile = Math.max(1, Math.min(100, Math.floor(Number(settings.perFile) || 1)));
  const total = sheets * 14;
  const winners = activePrizes.reduce((s, p) => s + (Number(settings.qty[p.id]) || 0), 0);
  const plan = useMemo(() => qrPlan(settings), [settings]);
  const ver = verdict(plan.lay.m);

  /* the saved template */
  useEffect(() => {
    let alive = true;
    loadSavedTpl().then(async (b) => {
      if (!b || !b.bytes || !alive) return;
      const bytes = new Uint8Array(b.bytes);
      const info = await checkTpl(bytes, b.name);
      if (alive) setTpl({ bytes, info, note: null });
    }).catch(() => {});
    return () => { alive = false; };
  }, []);

  async function onTplFile(ev) {
    const f = ev.target.files && ev.target.files[0];
    if (!f) return;
    setTpl((t) => ({ ...t, note: { kind: 'info', text: 'Reading the PDF…' } }));
    try {
      const bytes = new Uint8Array(await f.arrayBuffer());
      const info = await checkTpl(bytes, f.name);
      if (info.pages !== 1 || !info.a4) {
        setTpl((t) => ({ ...t, note: { kind: 'bad', text: 'This does not look like the one-page A4 template. Please choose Munch_Mix_A4_QR_Ready_Template.pdf' } }));
        return;
      }
      try { await saveTpl(bytes, f.name); } catch (e) { /* still usable this time */ }
      setTpl({ bytes, info, note: null });
    } catch (e) {
      setTpl((t) => ({ ...t, note: { kind: 'bad', text: 'That file could not be read as a PDF.' } }));
    }
  }

  /* previews */
  useEffect(() => {
    const a = new Image();
    const b = new Image();
    a.onload = () => setImgs((s) => ({ ...s, page: a }));
    b.onload = () => setImgs((s) => ({ ...s, hdr: b }));
    a.src = prevPageSrc;
    b.src = prevHdrSrc;
  }, []);

  useEffect(() => {
    if (!imgs.page || !imgs.hdr || !pageCv.current || !hdrCv.current) return;
    const cv = pageCv.current;
    cv.width = imgs.page.naturalWidth;
    cv.height = imgs.page.naturalHeight;
    const ctx = cv.getContext('2d');
    ctx.drawImage(imgs.page, 0, 0);
    const k = cv.width / 210;
    const px = (v) => v * k;
    px.k = k;
    for (let i = 0; i < 14; i++) paintQr(ctx, px, i, plan);

    const cv2 = hdrCv.current;
    cv2.width = imgs.hdr.naturalWidth;
    cv2.height = imgs.hdr.naturalHeight;
    const c2 = cv2.getContext('2d');
    c2.drawImage(imgs.hdr, 0, 0);
    const k2 = cv2.width / ((1160 / 300) * 25.4);
    const ox = (100 / 300) * 25.4;
    const oy = (130 / 300) * 25.4;
    const px2 = (v, isY) => (v - (isY ? oy : ox)) * k2;
    px2.k = k2;
    paintQr(c2, px2, 0, plan);
  }, [imgs, plan]);

  /* checks before making anything */
  function ready() {
    if (!tpl.bytes) { setMsg({ kind: 'bad', text: 'Load the print template first (step 1).' }); return false; }
    if (!plan.valid) { setMsg({ kind: 'bad', text: 'Enter your live website link first (step 2). It must start with https://' }); return false; }
    if (plan.lay.m < 0.3) { setMsg({ kind: 'bad', text: 'The QR dots would be too small to print reliably. Choose the larger QR or Low error repair.' }); return false; }
    if (/example|your-site|localhost/i.test(plan.base) && !window.confirm('This website link looks like a placeholder:\n' + plan.base + '\nQR codes printed with it will not work. Continue anyway?')) return false;
    return true;
  }

  async function testSheet() {
    if (!ready()) return;
    setMsg({ kind: 'info', text: 'Making the test sheet…' });
    try {
      const items = [];
      for (let i = 0; i < 14; i++) items.push({ t: randToken() });
      const bytes = await buildPdf(items, plan, tpl.bytes, tpl.info);
      downloadFile(bytes, 'MunchMix_TEST_SHEET.pdf', 'application/pdf');
      setMsg({ kind: 'ok', text: 'Test sheet made. Print it, then scan it with 2 or 3 different phones. It should open your website link.' });
    } catch (e) { setMsg({ kind: 'bad', text: 'Could not make the PDF: ' + (e.message || 'unknown error') }); }
  }

  const showFiles = useCallback((batch, items) => {
    setFiles({ batch, items });
    setTimeout(() => { if (filesRef.current && filesRef.current.scrollIntoView) filesRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 50);
  }, []);

  async function runUpload() {
    const pend = pendingRef.current;
    setBusy(true);
    setMsg({ kind: 'info', text: 'Saving codes to your database…' });
    setProgress(0);
    try {
      for (let i = 0; i < pend.items.length; i += 500) {
        const chunk = pend.items.slice(i, i + 500);
        const r = await addCodes(pend.batch, chunk);
        if (r.status !== 'ok') throw new Error('The database said: ' + r.status + (r.token ? ' (' + r.token + ')' : '') + '. Nothing is printed yet. Press the button again to retry.');
        setProgress(Math.min(1, (i + chunk.length) / pend.items.length));
      }
      pend.saved = true;
      setProgress(null);
      setMsg({ kind: 'ok', text: 'Saved ' + pend.items.length + ' codes as batch ' + pend.batch + '. Now make the PDF files below.' });
      await onChanged();
      showFiles(pend.batch, pend.items.slice());
    } catch (e) {
      setProgress(null);
      setMsg({ kind: 'bad', text: e.message || 'Could not save the codes. Check your internet and try again.' });
    }
    setBusy(false);
  }

  async function createBatch() {
    if (!ready()) return;
    if (winners > total) { setMsg({ kind: 'bad', text: 'You asked for more winning codes than there are packs.' }); return; }
    const pend = pendingRef.current;
    if (pend && !pend.saved) {
      if (window.confirm('An earlier batch (' + pend.batch + ') did not finish saving.\nPress OK to finish it, or Cancel to start a new one.')) { runUpload(); return; }
      pendingRef.current = null;
    }
    if (!window.confirm('Create ' + total + ' codes (' + sheets + ' sheets)?\n' + winners + ' of them will be winning codes.\nThey are saved to your database first, then the PDF files are made.')) return;

    const tokens = [];
    const seen = {};
    while (tokens.length < total) {
      const t = randToken();
      if (!seen[t]) { seen[t] = 1; tokens.push(t); }
    }
    const prizeArr = [];
    activePrizes.forEach((p) => { for (let i = 0; i < (Number(settings.qty[p.id]) || 0); i++) prizeArr.push(p.id); });
    while (prizeArr.length < total) prizeArr.push('');
    for (let i = prizeArr.length - 1; i > 0; i--) {
      const j = randInt(i + 1);
      const tmp = prizeArr[i]; prizeArr[i] = prizeArr[j]; prizeArr[j] = tmp;
    }
    const d = new Date();
    const ymd = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
    const used = {};
    ((stats && stats.batches) || []).forEach((b) => { used[b.batch] = 1; });
    let batch;
    do { batch = 'B' + ymd + '-' + randBatchSuffix(); } while (used[batch]);
    pendingRef.current = { batch, saved: false, items: tokens.map((t, i) => ({ t, p: prizeArr[i], s: i + 1 })) };
    await runUpload();
  }

  /* reprint an old batch (asked for from the Overview tab) */
  useEffect(() => {
    if (!reprint) return;
    let alive = true;
    setMsg({ kind: 'info', text: 'Loading batch ' + reprint + '…' });
    getBatchTokens(reprint).then((items) => {
      if (!alive) return;
      if (!items.length) { setMsg({ kind: 'bad', text: 'Could not load that batch.' }); return; }
      setMsg({ kind: 'ok', text: 'Loaded batch ' + reprint + ' (' + items.length + ' codes).' });
      showFiles(reprint, items);
    }).catch((e) => { if (alive) setMsg({ kind: 'bad', text: 'Could not load that batch: ' + e.message }); })
      .finally(() => { if (alive) onReprintDone(); });
    return () => { alive = false; };
  }, [reprint, onReprintDone, showFiles]);

  async function makePart(a, b, part) {
    if (!ready()) return;
    setPartBusy(part);
    try {
      const items = files.items.slice(a * 14, b * 14);
      const bytes = await buildPdf(items, plan, tpl.bytes, tpl.info);
      downloadFile(bytes, 'MunchMix_' + files.batch + '_part' + String(part).padStart(2, '0') + '_sheets' + (a + 1) + '-' + b + '.pdf', 'application/pdf');
      setMsg({ kind: 'ok', text: 'PDF ' + part + ' is ready. Check your downloads.' });
    } catch (e) { setMsg({ kind: 'bad', text: 'Could not make the PDF: ' + (e.message || 'unknown error') }); }
    setPartBusy(-1);
  }

  function manifest() {
    const names = {};
    prizes.forEach((p) => { names[p.id] = p.name; });
    const lines = [['serial', 'sheet', 'position', 'code', 'prize', 'link'].map(csvCell).join(',')];
    files.items.forEach((it) => {
      const s = it.s - 1;
      lines.push([it.s, Math.floor(s / 14) + 1, (s % 14) + 1, it.t, it.p ? (names[it.p] || it.p) : '', plan.base + '/c/' + it.t].map(csvCell).join(','));
    });
    downloadFile('\ufeff' + lines.join('\r\n'), 'MunchMix_' + files.batch + '_manifest.csv', 'text/csv;charset=utf-8');
  }

  const fileSheets = files ? Math.ceil(files.items.length / 14) : 0;
  const parts = [];
  for (let a = 0, part = 1; a < fileSheets; a += perFile, part++) parts.push({ a, b: Math.min(fileSheets, a + perFile), part });
  const pdfCount = Math.ceil(sheets / perFile);
  const dots = Math.round((plan.lay.m / 25.4) * 600 * 10) / 10;

  return (
    <section>
      <h2>Print sheets</h2>

      <div className="card">
        <h3>1. Print template</h3>
        <p className="muted">Choose <b>Munch_Mix_A4_QR_Ready_Template.pdf</b>. It is saved on this device, so you only do this once.</p>
        <input type="file" accept="application/pdf" onChange={onTplFile} />
        {tpl.note ? <Msg {...tpl.note} /> : null}
        {!tpl.note && !tpl.info ? <Msg kind="info" text="No template loaded yet." /> : null}
        {!tpl.note && tpl.info ? (
          <Msg kind={tpl.info.sameAsKnown ? 'ok' : 'bad'}
            text={tpl.info.sameAsKnown
              ? 'Template ready: ' + tpl.info.name + '. It is the exact file the QR positions were measured on.'
              : 'Loaded ' + tpl.info.name + ', but it is NOT the same file the QR positions were measured on. The QR codes may land in the wrong place. Use the preview, or choose Munch_Mix_A4_QR_Ready_Template.pdf.'} />
        ) : null}
      </div>

      <div className="card">
        <h3>2. QR link</h3>
        <label htmlFor="siteUrl">Your live website link</label>
        <input id="siteUrl" type="url" inputMode="url" placeholder="https://your-site.vercel.app" value={settings.siteUrl} onChange={(e) => update({ siteUrl: e.target.value.trim() })} />
        <p className="muted">Every QR opens this link + /c/ + the code. Use the final live link. QR codes printed with the wrong link cannot be fixed.</p>
        <div className="two">
          <div>
            <label htmlFor="qrMode">QR size on the header</label>
            <select id="qrMode" value={settings.mode} onChange={(e) => update({ mode: e.target.value })}>
              <option value="keep">Keep artwork (QR above SCAN &amp; WIN)</option>
              <option value="large">Larger QR (covers SCAN &amp; WIN)</option>
            </select>
          </div>
          <div>
            <label htmlFor="qrEcc">Error repair</label>
            <select id="qrEcc" value={settings.ecc} onChange={(e) => update({ ecc: e.target.value })}>
              <option value="auto">Auto (smallest dots)</option>
              <option value="M">Medium (safer if scuffed)</option>
              <option value="L">Low (bigger dots)</option>
            </select>
          </div>
        </div>
        <div className="msg info">
          <div>QR size: {plan.n} × {plan.n} dots, about {Math.round(plan.lay.size * 10) / 10} mm wide.</div>
          <div>Each dot: {Math.round(plan.lay.m * 100) / 100} mm (about {dots} printer dots at 600 dpi).</div>
          <div style={{ marginTop: 6 }}><span className={'ver ' + ver[0]}>{ver[1]}</span></div>
        </div>
        {!plan.valid ? <Msg kind="bad" text="Enter your live website link above (it must start with https://)." /> : null}
      </div>

      <div className="card">
        <h3>3. This batch</h3>
        <div className="two">
          <div>
            <label htmlFor="sheetsN">Number of A4 sheets (14 packs each)</label>
            <input id="sheetsN" type="number" min="1" max="1000" step="1" value={settings.sheets} onChange={(e) => update({ sheets: e.target.value })} />
          </div>
          <div>
            <label htmlFor="perFile">Sheets per PDF file</label>
            <input id="perFile" type="number" min="1" max="100" step="1" value={settings.perFile} onChange={(e) => update({ perFile: e.target.value })} />
          </div>
        </div>
        <label>How many winning codes of each prize?</label>
        {activePrizes.length ? activePrizes.map((p) => (
          <div className="qty" key={p.id}>
            {p.image ? <img className="thumb" style={{ width: 40, height: 40 }} src={p.image} alt="" /> : null}
            <span>{p.name}</span>
            <input type="number" min="0" step="1" value={settings.qty[p.id] || 0}
              onChange={(e) => update({ qty: { ...settings.qty, [p.id]: Math.max(0, Math.floor(Number(e.target.value) || 0)) } })} />
          </div>
        )) : <p className="muted">No prizes yet. Add one in the Prizes tab, or make a batch with no winning codes.</p>}
        <div className={'msg ' + (winners > total ? 'bad' : 'info')}>
          {total} packs · {winners} winning ({total ? Math.round((winners / total) * 1000) / 10 : 0}%) · {total - winners} without a prize · {pdfCount} PDF file{pdfCount === 1 ? '' : 's'}{winners > total ? ' — too many winning codes!' : ''}
        </div>
      </div>

      <div className="card">
        <h3>Preview</h3>
        <canvas ref={pageCv} aria-label="Sheet preview" />
        <p className="muted">Close-up of one header, drawn to real size:</p>
        <canvas ref={hdrCv} aria-label="Header close-up" />
      </div>

      <div className="card">
        <div className="row">
          <button className="btn yel" type="button" disabled={busy} onClick={createBatch}>Create codes and PDF files</button>
          <button className="btn alt" type="button" onClick={testSheet}>Make 1 test sheet (not saved)</button>
        </div>
        <p className="muted">The test sheet only checks that your phone can read the QR and open your link. It says "not found" because test codes are not saved.</p>
        {progress != null ? <div className="bar"><i style={{ width: Math.round(progress * 100) + '%' }} /></div> : null}
        <Msg {...(msg || {})} />
      </div>

      {files ? (
        <div className="card" ref={filesRef}>
          <h3>Files for batch {files.batch}</h3>
          <Msg kind="info" text={files.items.length + ' codes · ' + fileSheets + ' sheets · QR link: ' + (normBase(settings.siteUrl) || '(not set)') + '/c/…'} />
          <Msg kind="bad" text="Before printing in bulk: print the first sheet, scan every QR with 2–3 phones, and scan one code on the live site." />
          <div className="row" style={{ marginTop: 10 }}>
            {parts.map((p) => (
              <button key={p.part} className="btn" type="button" disabled={partBusy === p.part} onClick={() => makePart(p.a, p.b, p.part)}>
                {partBusy === p.part ? 'Making…' : 'PDF ' + p.part + ' (sheets ' + (p.a + 1) + '–' + p.b + ')'}
              </button>
            ))}
            <button className="btn alt" type="button" onClick={manifest}>Manifest (CSV, private)</button>
          </div>
        </div>
      ) : null}
    </section>
  );
}
