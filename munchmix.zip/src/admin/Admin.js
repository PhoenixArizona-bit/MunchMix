import React, { useCallback, useEffect, useState } from 'react';
import './admin.css';
import { supabase, LIVE } from '../supabaseClient';
import { getStats, getPrizes } from './api';
import OverviewTab from './OverviewTab';
import WinnersTab from './WinnersTab';
import PrizesTab from './PrizesTab';
import PrintTab from './PrintTab';
import Msg from './Msg';

const TABS = [['overview', 'Overview'], ['winners', 'Winners'], ['prizes', 'Prizes'], ['print', 'Print sheets']];

function Login({ note }) {
  const [email, setEmail] = useState(() => { try { return localStorage.getItem('mm_admin_email') || ''; } catch (e) { return ''; } });
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState(note ? { kind: 'bad', text: note } : null);
  const [busy, setBusy] = useState(false);

  async function go(e) {
    if (e) e.preventDefault();
    if (!email.trim() || !pw) { setMsg({ kind: 'bad', text: 'Enter your admin email and password.' }); return; }
    setBusy(true);
    setMsg({ kind: 'info', text: 'Checking…' });
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
    setBusy(false);
    if (error) {
      setMsg({ kind: 'bad', text: /rate|too many/i.test(error.message) ? 'Too many tries. Wait a few minutes, then try again.' : 'Wrong email or password.' });
      return;
    }
    try { localStorage.setItem('mm_admin_email', email.trim()); } catch (err) { /* ignore */ }
    setMsg(null);
  }

  return (
    <form className="login card" style={{ width: 'min(440px,92%)' }} onSubmit={go}>
      <h1>Munch Mix <b style={{ color: 'var(--red)' }}>Admin</b></h1>
      <p className="muted">Private page. Log in with your admin email and password.</p>
      <label htmlFor="adminEmail">Admin email</label>
      <input id="adminEmail" type="email" autoComplete="username" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <label htmlFor="adminPw">Password</label>
      <input id="adminPw" type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} />
      <div className="row" style={{ marginTop: 14 }}>
        <button className="btn" type="submit" disabled={busy}>Log in</button>
      </div>
      <Msg {...(msg || {})} />
    </form>
  );
}

function Dashboard({ onLogout }) {
  const [tab, setTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [prizes, setPrizes] = useState([]);
  const [msg, setMsg] = useState(null);
  const [reprint, setReprint] = useState('');

  const refresh = useCallback(async () => {
    try {
      const [s, p] = await Promise.all([getStats(), getPrizes()]);
      setStats(s);
      setPrizes(p);
      setMsg(null);
    } catch (e) {
      setMsg({ kind: 'bad', text: 'Could not load data: ' + (e.message || 'unknown problem') + '. Check that the setup SQL ran without errors in Supabase.' });
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  function go(t) {
    setTab(t);
    if (t === 'overview') refresh();
    window.scrollTo(0, 0);
  }

  return (
    <>
      <div className="top">
        <div className="top-row">
          <div className="brand">MUNCH <b>MIX</b> · Admin</div>
          <button className="btn small yel" type="button" onClick={onLogout}>Log out</button>
        </div>
        <div className="tabs" role="tablist">
          {TABS.map(([id, label]) => (
            <button key={id} type="button" className={'tab-btn' + (tab === id ? ' on' : '')} onClick={() => go(id)}>{label}</button>
          ))}
        </div>
      </div>
      <main>
        <Msg {...(msg || {})} />
        {tab === 'overview' ? (
          <OverviewTab stats={stats} onRefresh={refresh} setMsg={setMsg}
            onReprint={(b) => { setReprint(b); setTab('print'); window.scrollTo(0, 0); }} />
        ) : null}
        {tab === 'winners' ? <WinnersTab prizes={prizes} setMsg={setMsg} /> : null}
        {tab === 'prizes' ? <PrizesTab prizes={prizes} onChanged={refresh} setMsg={setMsg} /> : null}
        {tab === 'print' ? (
          <PrintTab prizes={prizes} stats={stats} onChanged={refresh} reprint={reprint} onReprintDone={() => setReprint('')} />
        ) : null}
      </main>
    </>
  );
}

export default function Admin() {
  const [session, setSession] = useState(undefined);
  const [state, setState] = useState('checking'); // checking | ok | notAdmin

  useEffect(() => {
    let meta = document.querySelector('meta[name="robots"]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'robots'; document.head.appendChild(meta); }
    meta.content = 'noindex,nofollow';
    document.title = 'Munch Mix Admin';
  }, []);

  useEffect(() => {
    if (!LIVE) return undefined;
    supabase.auth.getSession().then(({ data }) => setSession(data.session || null));
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s || null));
    return () => data.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) { setState('checking'); return; }
    let alive = true;
    // only real admins can run this; everyone else gets an error
    getStats().then(() => { if (alive) setState('ok'); }).catch(() => { if (alive) setState('notAdmin'); });
    return () => { alive = false; };
  }, [session]);

  const logout = () => { supabase.auth.signOut(); };

  if (!LIVE) {
    return (
      <div className="login card" style={{ width: 'min(520px,92%)' }}>
        <h1>Munch Mix <b style={{ color: 'var(--red)' }}>Admin</b></h1>
        <Msg kind="bad" text="Supabase is not connected. In Vercel, add REACT_APP_SUPABASE_URL and REACT_APP_SUPABASE_ANON_KEY under Settings > Environment Variables, then redeploy." />
      </div>
    );
  }
  if (session === undefined) return <div style={{ padding: 24 }}>Loading…</div>;
  if (!session) return <Login />;
  if (state === 'checking') return <div style={{ padding: 24 }}>Checking your account…</div>;
  if (state === 'notAdmin') {
    return (
      <div className="login card" style={{ width: 'min(520px,92%)' }}>
        <h1>Not an admin yet</h1>
        <Msg kind="bad" text="You are signed in, but this account is not an admin. Run the STEP 2 line from the setup SQL in Supabase with this email, then log in again." />
        <div className="row" style={{ marginTop: 12 }}><button className="btn" type="button" onClick={logout}>Log out</button></div>
      </div>
    );
  }
  return <Dashboard onLogout={logout} />;
}
