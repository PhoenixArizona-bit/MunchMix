import React from 'react';

export default function Msg({ kind, text }) {
  return text ? <div className={'msg ' + kind}>{text}</div> : null;
}
