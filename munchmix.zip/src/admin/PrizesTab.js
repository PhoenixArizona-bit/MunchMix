import React, { useState } from 'react';
import { savePrize, deletePrize, uploadPrizeImage } from './api';
import Msg from './Msg';

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const u = URL.createObjectURL(file);
    const im = new Image();
    im.onload = () => { URL.revokeObjectURL(u); resolve(im); };
    im.onerror = () => { URL.revokeObjectURL(u); reject(new Error('bad image')); };
    im.src = u;
  });
}
const toBlob = (c, q) => new Promise((res) => c.toBlob(res, 'image/jpeg', q));

// shrink the picture in the browser so it is small and fast
async function shrinkImage(file) {
  const im = await loadImage(file);
  let dim = 640;
  for (let round = 0; round < 6; round++) {
    const sc = Math.min(1, dim / Math.max(im.naturalWidth, im.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(im.naturalWidth * sc));
    c.height = Math.max(1, Math.round(im.naturalHeight * sc));
    const x = c.getContext('2d');
    x.fillStyle = '#fff';
    x.fillRect(0, 0, c.width, c.height);
    x.drawImage(im, 0, 0, c.width, c.height);
    for (const q of [0.85, 0.75, 0.65, 0.55]) {
      const b = await toBlob(c, q);
      if (b && b.size <= 400000) return b;
    }
    dim = Math.round(dim * 0.8);
  }
  throw new Error('too big');
}

export default function PrizesTab({ prizes, onChanged, setMsg }) {
  const [form, setForm] = useState(null); // null = closed
  const [msg, setLocal] = useState(null);
  const [busy, setBusy] = useState(false);

  const open = (p) => {
    setLocal(null);
    setForm(p
      ? { id: p.id, name: p.name, description: p.description, active: p.active, image: p.image, blob: null }
      : { id: '', name: '', description: '', active: true, image: '', blob: null });
  };
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));

  async function pick(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    try {
      const blob = await shrinkImage(f);
      set({ blob, image: URL.createObjectURL(blob) });
      setLocal(null);
    } catch (err) { setLocal({ kind: 'bad', text: 'That picture could not be used. Try another one.' }); }
  }

  async function save() {
    const name = form.name.trim();
    if (!name) { setLocal({ kind: 'bad', text: 'Give the prize a name.' }); return; }
    setBusy(true);
    setLocal({ kind: 'info', text: 'Saving…' });
    try {
      let image = /^https:\/\//i.test(form.image) ? form.image : '';
      if (form.blob) { setLocal({ kind: 'info', text: 'Uploading the picture…' }); image = await uploadPrizeImage(form.blob); }
      await savePrize({ id: form.id, name, description: form.description.trim(), image, active: form.active });
      setForm(null);
      await onChanged();
    } catch (e) { setLocal({ kind: 'bad', text: 'Could not save: ' + e.message }); }
    setBusy(false);
  }

  async function remove(p) {
    if (!window.confirm('Delete "' + p.name + '"?\nIf codes already use it, it is only switched off.')) return;
    try {
      const r = await deletePrize(p.id);
      if (r.deactivated) window.alert('This prize is used by printed codes, so it was switched off instead of deleted.');
      await onChanged();
    } catch (e) { setMsg({ kind: 'bad', text: 'Could not delete: ' + e.message }); }
  }

  return (
    <section>
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
        <h2 style={{ margin: 0 }}>Prizes</h2>
        <button className="btn small yel" type="button" onClick={() => open(null)}>+ New prize</button>
      </div>
      <p className="muted">The winner sees the prize name, text and picture on the website after scanning a winning code.</p>

      {form ? (
        <div className="card">
          <h3>{form.id ? 'Edit prize' : 'New prize'}</h3>
          <label htmlFor="pfName">Prize name</label>
          <input id="pfName" type="text" maxLength={60} placeholder="e.g. Free snack box" value={form.name} onChange={(e) => set({ name: e.target.value })} />
          <label htmlFor="pfDesc">Short text (optional)</label>
          <textarea id="pfDesc" maxLength={200} value={form.description} onChange={(e) => set({ description: e.target.value })} />
          <label htmlFor="pfImg">Picture (optional)</label>
          <input id="pfImg" type="file" accept="image/*" onChange={pick} />
          {form.image ? (
            <div className="row" style={{ marginTop: 10 }}>
              <img className="thumb" src={form.image} alt="" />
              <button className="btn small red" type="button" onClick={() => set({ image: '', blob: null })}>Remove picture</button>
            </div>
          ) : null}
          <label><input type="checkbox" checked={form.active} onChange={(e) => set({ active: e.target.checked })} /> Available for new print batches</label>
          <div className="row" style={{ marginTop: 14 }}>
            <button className="btn" type="button" disabled={busy} onClick={save}>Save prize</button>
            <button className="btn alt" type="button" onClick={() => setForm(null)}>Cancel</button>
          </div>
          <Msg {...(msg || {})} />
        </div>
      ) : null}

      <div className="card">
        {prizes.length ? prizes.map((p) => (
          <div className="item" key={p.id}>
            {p.image ? <img className="thumb" src={p.image} alt="" /> : <div className="thumb">🎁</div>}
            <div className="grow">
              <div><b>{p.name}</b> {p.active ? null : <span className="tag r">off</span>}</div>
              <div className="muted">{p.description}</div>
              <div className="row" style={{ marginTop: 8 }}>
                <button className="btn small alt" type="button" onClick={() => open(p)}>Edit</button>
                <button className="btn small red" type="button" onClick={() => remove(p)}>Delete</button>
              </div>
            </div>
          </div>
        )) : <p className="muted">No prizes yet. Tap “+ New prize”.</p>}
      </div>
    </section>
  );
}
