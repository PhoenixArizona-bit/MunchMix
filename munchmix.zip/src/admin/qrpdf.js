import qrcode from 'qrcode-generator';
import { PDFDocument, cmyk } from 'pdf-lib';

/* Box positions (in millimetres from the top-left of the A4 page) were measured on
   Munch_Mix_A4_QR_Ready_Template.pdf: 2 columns x 7 rows, each box 18 mm. */
export const KNOWN_SHA = '9babc19326a36ccce9d171b0b3f7fd8d8ad1ce832d1a14f4b8c15977190769cb';
export const BOX_X = [80.94, 181.19];
export const BOX_Y = [16.43, 57.32, 98.3, 139.19, 180.09, 221.06, 261.96];
export const MODES = {
  keep: { x: 1.2, y: 1.2, w: 15.6, h: 12.3 },
  large: { x: 1.2, y: 1.2, w: 15.6, h: 15.6 },
};
const ALNUM = /^[0-9A-Z $%*+./:-]+$/;
const ABC = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

export function randInt(n) {
  const b = new Uint32Array(1);
  const lim = Math.floor(4294967296 / n) * n;
  do { crypto.getRandomValues(b); } while (b[0] >= lim);
  return b[0] % n;
}

export function randToken() {
  let out = '';
  const buf = new Uint8Array(32);
  while (out.length < 10) {
    crypto.getRandomValues(buf);
    for (let i = 0; i < buf.length && out.length < 10; i++) {
      if (buf[i] < 248) out += ABC[buf[i] % 31];
    }
  }
  return out;
}

export function randBatchSuffix() { return ABC[randInt(31)] + ABC[randInt(31)]; }

export function normBase(u) {
  const v = String(u || '').trim().replace(/\/+$/, '');
  return /^https:\/\/[a-z0-9.-]+(:\d+)?(\/[A-Za-z0-9._~/-]*)?$/i.test(v) ? v : '';
}

export function makeQr(token, ecc, base) {
  const raw = base + '/c/' + token;
  const up = raw.toUpperCase();
  const alnum = ALNUM.test(up);
  const q = qrcode(0, ecc);
  q.addData(alnum ? up : raw, alnum ? 'Alphanumeric' : 'Byte');
  q.make();
  return q;
}

export function pickEcc(base, setting) {
  if (setting === 'M' || setting === 'L') return setting;
  const l = makeQr('ABCDEFGHJK', 'L', base).getModuleCount();
  const m = makeQr('ABCDEFGHJK', 'M', base).getModuleCount();
  return l < m ? 'L' : 'M';
}

export function layoutFor(n, mode) {
  const r = MODES[mode];
  const side = Math.min(r.w, r.h);
  const m = Math.floor((side / (n + 4)) * 200) / 200;
  const size = m * n;
  return { m, size, ox: r.x + (r.w - size) / 2, oy: r.y + (r.h - size) / 2, patch: r };
}

export function verdict(m) {
  if (m >= 0.4) return ['good', 'Good: easy for any phone'];
  if (m >= 0.34) return ['ok', 'OK: works on most phones, print must be sharp'];
  return ['bad', 'Too small: use the larger QR, a shorter link, or Low error repair'];
}

export function qrPlan(settings) {
  const valid = Boolean(normBase(settings.siteUrl));
  const base = normBase(settings.siteUrl) || 'https://your-site.vercel.app';
  const ecc = pickEcc(base, settings.ecc);
  const q = makeQr('ABCDEFGHJK', ecc, base);
  const n = q.getModuleCount();
  return { base, valid, ecc, n, lay: layoutFor(n, settings.mode), q };
}

/* draw one QR on a canvas (used for the preview) */
export function paintQr(ctx, px, boxIdx, plan) {
  const bx = BOX_X[boxIdx % 2];
  const by = BOX_Y[Math.floor(boxIdx / 2)];
  const L = plan.lay;
  const p = L.patch;
  ctx.fillStyle = '#fff';
  ctx.fillRect(px(bx + p.x), px(by + p.y, true), p.w * px.k, p.h * px.k);
  ctx.fillStyle = '#000';
  const x0 = bx + L.ox;
  const y0 = by + L.oy;
  for (let r = 0; r < plan.n; r++) {
    for (let c = 0; c < plan.n; c++) {
      if (plan.q.isDark(r, c)) ctx.fillRect(px(x0 + c * L.m), px(y0 + r * L.m, true), L.m * px.k + 0.6, L.m * px.k + 0.6);
    }
  }
}

/* Build one PDF: the template page for every 14 items, with sharp vector QR codes on top. */
export async function buildPdf(items, plan, tplBytes, tplInfo) {
  const out = await PDFDocument.create();
  const emb = await out.embedPdf(tplBytes, [0]);
  const tpl = emb[0];
  const W = tplInfo.w;
  const H = tplInfo.h;
  const k = 72 / 25.4;
  const L = plan.lay;
  const eps = 0.03;
  const black = cmyk(0, 0, 0, 1);
  const white = cmyk(0, 0, 0, 0);
  for (let i = 0; i < items.length; i += 14) {
    const page = out.addPage([W, H]);
    page.drawPage(tpl, { x: 0, y: 0, width: W, height: H });
    for (let j = 0; j < 14 && i + j < items.length; j++) {
      const q = makeQr(items[i + j].t, plan.ecc, plan.base);
      const n = q.getModuleCount();
      const bx = BOX_X[j % 2];
      const by = BOX_Y[Math.floor(j / 2)];
      const p = L.patch;
      page.drawRectangle({ x: (bx + p.x) * k, y: H - (by + p.y + p.h) * k, width: p.w * k, height: p.h * k, color: white, borderWidth: 0 });
      const m = L.m * k;
      const X0 = (bx + L.ox) * k;
      const Ytop = (by + L.oy) * k;
      for (let r = 0; r < n; r++) {
        let c = 0;
        while (c < n) {
          if (q.isDark(r, c)) {
            const s = c;
            while (c < n && q.isDark(r, c)) c++;
            page.drawRectangle({ x: X0 + s * m - eps, y: H - (Ytop + (r + 1) * m) - eps, width: (c - s) * m + 2 * eps, height: m + 2 * eps, color: black, borderWidth: 0 });
          } else c++;
        }
      }
    }
  }
  return out.save();
}

/* ---- template file helpers ---- */
export async function sha256(bytes) {
  if (!(window.crypto && window.crypto.subtle)) return '';
  const d = await window.crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function checkTpl(bytes, name) {
  const doc = await PDFDocument.load(bytes);
  const sz = doc.getPage(0).getSize();
  const sha = await sha256(bytes);
  return {
    name,
    size: bytes.length,
    pages: doc.getPageCount(),
    w: sz.width,
    h: sz.height,
    sha,
    sameAsKnown: sha === KNOWN_SHA,
    a4: Math.abs(sz.width - 595.276) < 2 && Math.abs(sz.height - 841.89) < 2,
  };
}

function idb(mode, fn) {
  return new Promise((resolve, reject) => {
    try {
      const o = indexedDB.open('mm_admin', 1);
      o.onupgradeneeded = () => o.result.createObjectStore('kv');
      o.onsuccess = () => {
        const tx = o.result.transaction('kv', mode);
        const r = fn(tx.objectStore('kv'));
        tx.oncomplete = () => resolve(r && r.result);
        tx.onerror = () => reject(tx.error);
      };
      o.onerror = () => reject(o.error);
    } catch (e) { reject(e); }
  });
}
export const saveTpl = (bytes, name) => idb('readwrite', (st) => st.put({ bytes: bytes.buffer.slice(0), name }, 'tpl'));
export const loadSavedTpl = () => idb('readonly', (st) => st.get('tpl'));

/* ---- small utilities ---- */
export function csvCell(v) {
  let s = String(v == null ? '' : v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}

export function downloadFile(data, name, type) {
  const blob = new Blob([data], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 5000);
}

export function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleString();
}
