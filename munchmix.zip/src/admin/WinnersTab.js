import React, { useCallback, useEffect, useState } from 'react';
import { getWinners, setDelivered } from './api';
import { csvCell, downloadFile, fmtDate } from './qrpdf';

const bucket = (w) => (w.delivered ? 'delivered' : (w.phone ? 'todeliver' : 'needs'));

export default function WinnersTab({ prizes, setMsg }) {
  const [rows, setRows] = useState(null);
  const [filter, setFilter] = useState('all');
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    try { setRows(await getWinners()); setMsg(null); } catch (e) { setMsg({ kind: 'bad', text: 'Could not load winners: ' + e.message }); }
  }, [setMsg]);
  useEffect(() => { load(); }, [load]);

  async function toggle(w) {
    try {
      await setDelivered(w.token, !w.delivered);
      setRows((list) => list.map((x) => (x.token === w.token ? { ...x, delivered: !x.delivered } : x)));
    } catch (e) { setMsg({ kind: 'bad', text: 'Could not save: ' + e.message }); }
  }

  function csv() {
    const lines = [['Prize', 'Name', 'Phone', 'Scanned at', 'Details sent at', 'Delivered', 'Code end'].map(csvCell).join(',')];
    rows.forEach((w) => lines.push([w.prize_name, w.name, w.phone ? '+' + w.phone : '', fmtDate(w.redeemed_at), fmtDate(w.claimed_at), w.delivered ? 'yes' : 'no', '…' + w.token.slice(-4)].map(csvCell).join(',')));
    downloadFile('\ufeff' + lines.join('\r\n'), 'munchmix_winners.csv', 'text/csv;charset=utf-8');
  }

  if (!rows) return <p className="muted">Loading…</p>;
  const counts = { all: rows.length, needs: 0, todeliver: 0, delivered: 0 };
  rows.forEach((w) => { counts[bucket(w)]++; });
  const needle = q.trim().toLowerCase();
  const shown = rows.filter((w) => (filter === 'all' || bucket(w) === filter)
    && (!needle || (w.name + ' ' + w.phone + ' ' + w.prize_name + ' ' + w.token.slice(-4)).toLowerCase().indexOf(needle) >= 0));
  const imgs = {};
  prizes.forEach((p) => { imgs[p.id] = p.image; });

  return (
    <section>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>Winners</h2>
        <button className="btn small alt" type="button" onClick={csv}>Download list (CSV)</button>
      </div>
      <div className="chips">
        {[['all', 'All'], ['needs', 'No details yet'], ['todeliver', 'To deliver'], ['delivered', 'Delivered']].map(([id, label]) => (
          <button key={id} type="button" className={'chip' + (filter === id ? ' on' : '')} onClick={() => setFilter(id)}>{label} ({counts[id]})</button>
        ))}
      </div>
      <input type="search" placeholder="Search name, phone, prize or code end" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="card" style={{ marginTop: 14 }}>
        {shown.length ? shown.map((w) => (
          <div className="item" key={w.token}>
            {imgs[w.prize_id] ? <img className="thumb" src={imgs[w.prize_id]} alt="" /> : <div className="thumb">🎁</div>}
            <div className="grow">
              <div>
                <b>{w.prize_name}</b>{' '}
                <span className={'tag ' + (w.delivered ? 'g' : (w.phone ? '' : 'r'))}>{w.delivered ? 'delivered' : (w.phone ? 'to deliver' : 'no details')}</span>
              </div>
              <div>{w.name || '(name not sent yet)'}</div>
              {w.phone ? <div className="muted">+{w.phone}</div> : null}
              <div className="muted">Code …{w.token.slice(-4)} · scanned {fmtDate(w.redeemed_at)}</div>
              {w.phone ? (
                <div className="row" style={{ marginTop: 8 }}>
                  <a className="btn small alt" href={'https://wa.me/' + w.phone} target="_blank" rel="noopener noreferrer">WhatsApp</a>
                  <a className="btn small alt" href={'tel:+' + w.phone}>Call</a>
                  <button className={'btn small ' + (w.delivered ? 'red' : 'yel')} type="button" onClick={() => toggle(w)}>{w.delivered ? 'Undo delivered' : 'Mark delivered'}</button>
                </div>
              ) : null}
            </div>
          </div>
        )) : <p className="muted">Nothing here yet.</p>}
      </div>
    </section>
  );
}
